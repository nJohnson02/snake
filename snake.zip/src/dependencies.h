// Nathan Johnson
// Tiaron Starrine

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <windows.h>
#include <winuser.h>