#define ROWS 20
#define COLS 20
#define SPEED 150

void colorRed();
void colorGreen();
void colorDefault();
void drawFrame();
char checkKb();
